declare module '*.vue' {
  import Vue from 'vue'
  export default Vue
}

declare module 'chance'
declare module 'prismjs'
declare module 'prismjs/*'
