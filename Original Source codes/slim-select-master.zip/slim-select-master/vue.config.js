module.exports = {
  parallel: false,
  outputDir: 'docs',
  // pages: {
  //   index: {
  //     entry: 'src/docs/index.ts',
  //     template: 'public/index.html',
  //     filename: 'index.html'
  //   }
  // },
  // configureWebpack: {
  //   output: {
  //     filename: 'js/[name].js',
  //     chunkFilename: 'js/[name].js'
  //   }
  // },
  // css: {
  //   extract: {
  //     filename: 'css/[name].css',
  //     chunkFilename: 'css/[name].css'
  //   },
  // }
}